# LearnDNA — Web Version

Ye tumhare Java LearnDNA project ka **website version** hai — same logic (Knowledge Graph, topological sort, rule-based recommendation engine, mastery scoring, revision planner), bas ab ye seedha browser mein chalega. Koi Java compile / classpath / IDE setup nahi chahiye.

## Kaise chalayein (2 tareeke)

**Sabse simple:** `index.html` file par seedha double-click karo — browser mein khul jayega, poora app kaam karega.

**Better (recommended for demo/viva):** kisi bhi text editor / VS Code se folder kholo aur ek local server chalao, phir browser mein `http://localhost:8000` kholo:
```
python3 -m http.server 8000
```
(Local server thoda zyada reliable hai kyunki fonts vagera load hote hain, lekin double-click wala tareeka bhi 100% chalega.)

Koi npm install, koi backend, koi database setup nahi chahiye — sab kuch pure HTML/CSS/JS hai, data browser ke `localStorage` mein save hota hai (naya student banao ya wapas login karo, same email se progress wapas mil jayega).

## Flow

1. **Sign in** — naam + email daalo (naya profile automatic ban jata hai)
2. **Goal chuno** — Java Backend Developer ya Database Fundamentals
3. **Self-assessment** — har topic pe "Don't know / Somewhat / Confident" — isse tumhari **Knowledge DNA** banti hai
4. **Dashboard** — overall DNA score, weak areas, recommended next topics
5. **Knowledge Graph Explorer** — sabhi topics aur unke prerequisites ka visual graph (teal = mastered, amber = ready, coral = locked)
6. **Roadmap** — goal-backward planning se generate hua ordered learning path (topological sort)
7. **Topic page** — resources complete karo, mastery badhti hai
8. **Quiz** — 3 MCQs per topic, submit karne pe mastery score update hoti hai
9. **Revision planner** — jo topics 3+ din se revise nahi kiye, wo yaha flag hote hain
10. **Analytics** — domain-wise (Java / Database / Web) average mastery

## File structure

```
index.html          -> entry point, isko hi open karna hai
css/styles.css       -> saara styling
js/data.js           -> seed data: 9 topics, 2 goals, quiz questions (Java DataSeeder se liya)
js/models.js         -> Topic, Goal, Student, KnowledgeDNA, ProgressTracker classes
js/graph.js          -> KnowledgeGraph: BFS, DFS, topological sort, prerequisite checking
js/engine.js         -> RuleBasedRecommendationEngine + revision queue logic
js/store.js          -> localStorage persistence layer
js/app.js            -> routing + saari screens ka rendering
```

## Java se mapping (viva ke liye)

Ye web version tumhare original Java classes ke naam aur logic ko hi follow karta hai, taaki explain karna easy rahe:

| Java class | Web equivalent |
|---|---|
| `learndna.model.Topic`, `Goal`, `Student`, `KnowledgeDNA` | `js/models.js` — same fields, same methods |
| `learndna.graph.KnowledgeGraph` (BFS/DFS/Kahn's topo sort/cycle check) | `js/graph.js` — line-by-line same algorithm, JS Map/Set instead of Java HashMap/HashSet |
| `learndna.engine.RuleBasedRecommendationEngine` (goal relevance + readiness + weakness + time fit scoring) | `js/engine.js` — same scoring formula |
| `learndna.util.DataSeeder` | `js/data.js` — same T1–T9 topics, same G1 goal, same prerequisite edges |
| Java Swing GUI (`MainFrame`, `DashboardPanel`, `RoadmapPanel`, `TopicExplorerPanel`, `QuizPanel`) | `js/app.js` screens — Dashboard, Roadmap, Graph Explorer, Topic page, Quiz |
| JDBC Data Access Layer | `js/store.js` (`localStorage` — no server/DB needed for the demo) |

Isse tum bata sakte ho ki OOP design same hi hai, sirf presentation + persistence layer ko web ke liye swap kiya hai (jaisa documentation ke "Future Scope" mein already likha hai: *"Mobile/web version using Spring Boot + React/Android"*).

## Update v2
- **Auth:** Sign in + Create account tabs, password strength rules + live meter, show/hide, confirm password, lockout after 5 wrong tries. Password localStorage me **PBKDF2-SHA256 hash + salt** ke roop me save hota hai (inspect karne pe plain password nahi dikhega). `js/auth.js`
- **Quiz:** rounds of 5 (topic + prerequisite revision questions, shuffled), mastered (70%) hone tak naye rounds.
- **Roadmap/Topic:** har topic pe YouTube, full course, GeeksforGeeks, practice, NPTEL links. Optional YouTube Data API key daalo to topic page pe top-4 video cards aate hain.
- Note: ye frontend-only demo hai; production me hashing server par honi chahiye.
