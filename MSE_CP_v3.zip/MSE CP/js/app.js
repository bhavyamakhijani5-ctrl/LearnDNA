/* ===================================================================
   app.js — routing + screen rendering (Presentation Layer).
   In the original Java project this role belonged to the Swing GUI
   package (MainFrame, LoginFrame, DashboardPanel, RoadmapPanel,
   TopicExplorerPanel, QuizPanel). Same screens, same flow, now HTML.
   =================================================================== */

const root = document.getElementById("app");

// ---- build one Knowledge Graph PER SUBJECT + a Goal per subject (Domain layer wiring) ----
// Each subject (Java, C, C++, Python, DSA, DBMS, OOP...) is its own independent
// graph — prerequisites only make sense within a subject, so they never mix.
const SUBJECT_GRAPHS = new Map(); // subjectId -> KnowledgeGraph
const GOALS = new Map();          // subjectId -> Goal (requiredTopicIds = every topic in that subject)

SEED_SUBJECTS.forEach(subj => {
  const g = new KnowledgeGraph();
  subj.topics.forEach(t => g.addTopic(new Topic(t)));
  subj.edges.forEach(([pre, topic]) => g.addPrerequisite(pre, topic));
  SUBJECT_GRAPHS.set(subj.id, g);
  GOALS.set(subj.id, new Goal({
    id: subj.id,
    title: subj.title,
    description: subj.description,
    requiredTopicIds: subj.topics.map(t => t.id),
  }));
});

function currentGraph() {
  return SUBJECT_GRAPHS.get(CURRENT.activeGoalId);
}
function currentEngine() {
  return new RuleBasedRecommendationEngine(currentGraph(), GOALS);
}

// per-subject accent colour + icon, used to give each track its own identity
const SUBJECT_STYLE = {
  JAVA:   { color: "#EA580C", icon: "☕" },
  C:      { color: "#2563EB", icon: "🅲" },
  CPP:    { color: "#7C3AED", icon: "🎯" },
  PYTHON: { color: "#16A34A", icon: "🐍" },
  DSA:    { color: "#DB2777", icon: "🧩" },
  DBMS:   { color: "#0891B2", icon: "🗄️" },
  OOP:    { color: "#CA8A04", icon: "🧬" },
};
function subjectStyle(id) { return SUBJECT_STYLE[id] || { color: "#4F46E5", icon: "📘" }; }

let CURRENT = null; // active Student

// ---------------------------------------------------------------- utils

function h(strings, ...vals) { return strings.reduce((acc, s, i) => acc + s + (vals[i] ?? ""), ""); }
function esc(str) { const d = document.createElement("div"); d.textContent = str ?? ""; return d.innerHTML; }
function navigate(hash) { location.hash = hash; }
function toast(msg) {
  let el = document.getElementById("toast");
  if (!el) { el = document.createElement("div"); el.id = "toast"; document.body.appendChild(el); }
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 2200);
}
function masteryBadge(score) {
  if (score >= PASS_THRESHOLD) return `<span class="badge mastered">mastered</span>`;
  if (score > 0) return `<span class="badge building">building</span>`;
  return `<span class="badge neutral">not started</span>`;
}
function fmtDate(iso) {
  if (!iso) return "never";
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short" });
}


// ---------------------------------------------------------------- learning links
function topicLinks(t) {
  const q = encodeURIComponent(t.title.toLowerCase().includes(t.domain.toLowerCase()) ? t.title : `${t.title} ${t.domain}`);
  const g = (extra) => `https://www.google.com/search?q=${q}+${extra}`;
  return [
    ["▶ YouTube tutorial", `https://www.youtube.com/results?search_query=${q}+tutorial`],
    ["🎓 Full course (YouTube)", `https://www.youtube.com/results?search_query=${q}+full+course`],
    ["📚 GeeksforGeeks", g("site:geeksforgeeks.org")],
    ["📖 W3Schools / Docs", g("site:w3schools.com")],
    ["🧪 Practice problems", g("practice+problems+site:hackerrank.com+OR+site:leetcode.com")],
    ["🏫 NPTEL / freeCodeCamp", g("site:nptel.ac.in+OR+site:freecodecamp.org")],
  ];
}
function chips(t, all) {
  const l = topicLinks(t);
  return (all ? l : [l[0], l[4], l[1]]).map(([n, u]) => `<a class="chip" href="${u}" target="_blank" rel="noopener noreferrer">${n}</a>`).join("");
}
async function loadVideos(t, el) {
  if (!el) return;
  const key = localStorage.getItem("learndna:ytkey");
  const keyBox = (msg) => {
    el.innerHTML = `${msg || ""}<div class="yt-key"><input id="yt-key" placeholder="YouTube Data API v3 key (optional)"><button class="btn small" id="yt-save">Save &amp; load</button></div><p class="hint">Bina key ke upar wale YouTube links already kaam karte hain. Key free milti hai Google Cloud Console se.</p>`;
    document.getElementById("yt-save").onclick = () => { const v = document.getElementById("yt-key").value.trim(); if (v) { localStorage.setItem("learndna:ytkey", v); loadVideos(t, el); } };
  };
  if (!key) return keyBox();
  el.innerHTML = `<p class="hint">Loading videos…</p>`;
  try {
    const r = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=4&q=${encodeURIComponent(t.title + " " + t.domain + " tutorial")}&key=${encodeURIComponent(key)}`);
    const d = await r.json();
    if (!r.ok) throw new Error(d.error?.message || "YouTube API error");
    el.innerHTML = `<div class="yt-grid">${d.items.map(v => `<a class="yt-card" target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/watch?v=${v.id.videoId}"><img src="${v.snippet.thumbnails.medium.url}" alt=""><span>${esc(v.snippet.title)}</span><small>${esc(v.snippet.channelTitle)}</small></a>`).join("")}</div><button class="btn ghost small" id="yt-clear">Change API key</button>`;
    document.getElementById("yt-clear").onclick = () => { localStorage.removeItem("learndna:ytkey"); loadVideos(t, el); };
  } catch (ex) { localStorage.removeItem("learndna:ytkey"); keyBox(`<div class="error-msg">${esc(ex.message)}</div>`); }
}

// ---------------------------------------------------------------- router

window.addEventListener("hashchange", render);
window.addEventListener("DOMContentLoaded", () => {
  const email = Auth.currentEmail();
  if (email) CURRENT = Store.loadStudent(email);
  render();
});

function render() {
  const hash = location.hash.replace(/^#\/?/, "") || (CURRENT ? "dashboard" : "login");
  const [route, param] = hash.split("/");

  if (!CURRENT) { renderLogin(); return; }

  // Defensive: a profile saved by an older version of this app (before the
  // multi-subject update) may point at a goal id that no longer exists.
  // Instead of crashing into a blank page, just send them back to onboarding.
  if (CURRENT.activeGoalId && !GOALS.has(CURRENT.activeGoalId)) {
    CURRENT.activeGoalId = null;
  }
  if (!CURRENT.activeGoalId && route !== "onboarding") { navigate("/onboarding"); return; }

  try {
    switch (route) {
      case "login": renderLogin(); break;
      case "onboarding": renderOnboarding(); break;
      case "dashboard": renderDashboard(); break;
      case "graph": renderGraph(); break;
      case "roadmap": renderRoadmap(); break;
      case "topic": renderTopicDetail(param); break;
      case "quiz": renderQuiz(param); break;
      case "revision": renderRevision(); break;
      case "analytics": renderAnalytics(); break;
      case "subjects": renderSubjects(); break;
      default: renderDashboard();
    }
  } catch (err) {
    console.error("LearnDNA render error:", err);
    root.innerHTML = `
      <div class="center-screen">
        <div class="auth-card">
          <h1 style="font-size:19px;margin-bottom:10px;">Something went out of sync</h1>
          <p style="color:var(--text-dim);font-size:13.5px;margin-bottom:18px;">
            This usually happens when old saved data doesn't match the current app version.
            Resetting your local profile will fix it — you'll just redo the quick setup.
          </p>
          <button class="btn block" id="reset-btn">Reset &amp; start fresh</button>
        </div>
      </div>`;
    document.getElementById("reset-btn").addEventListener("click", () => {
      Store.clearAll();
      CURRENT = null;
      navigate("/login");
      location.reload();
    });
  }
}

function persist() { Store.saveStudent(CURRENT); }

// ---------------------------------------------------------------- brand

const HELIX_SVG = `<svg class="helix" viewBox="0 0 26 26" fill="none">
  <path d="M6 2c0 6 14 6 14 12s-14 6-14 12" stroke="#4F46E5" stroke-width="2" stroke-linecap="round"/>
  <path d="M20 2c0 6-14 6-14 12s14 6 14 12" stroke="#FB7185" stroke-width="2" stroke-linecap="round"/>
  <line x1="7.3" y1="6" x2="18.7" y2="6" stroke="#c7c1b2" stroke-width="1.4"/>
  <line x1="13" y1="13" x2="13" y2="13" stroke="#c7c1b2" stroke-width="1.4"/>
  <line x1="7.3" y1="20" x2="18.7" y2="20" stroke="#c7c1b2" stroke-width="1.4"/>
</svg>`;

// ---------------------------------------------------------------- login

function pwField(id, label, ac) {
  return `<div class="field"><label>${label}</label><div class="pw-wrap"><input type="password" id="${id}" autocomplete="${ac}" required><button type="button" class="pw-eye" data-eye="${id}" aria-label="Show or hide password">Show</button></div></div>`;
}

function renderLogin(mode = "login", pre = {}) {
  const reg = mode === "register";
  const $ = (id) => document.getElementById(id);
  root.innerHTML = `
  <div class="center-screen"><div class="auth-card" style="max-width:${reg ? 440 : 410}px;">
    <div class="brand">${HELIX_SVG}<div><div class="brand-name">LearnDNA</div><div class="brand-tag">smart learning engine</div></div></div>
    <div class="auth-tabs"><button data-mode="login" class="${reg ? "" : "on"}">Sign in</button><button data-mode="register" class="${reg ? "on" : ""}">Create account</button></div>
    ${pre.notice ? `<div class="explain-box ready" style="margin-bottom:14px;">${esc(pre.notice)}</div>` : ""}
    <form id="auth-form">
      ${reg ? `<div class="field"><label>Full name</label><input type="text" id="f-name" autocomplete="name" value="${esc(pre.name || "")}" required></div>` : ""}
      <div class="field"><label>College email</label><input type="email" id="f-email" autocomplete="email" placeholder="you@vit.edu" value="${esc(pre.email || "")}" required></div>
      ${pwField("f-pass", reg ? "Create password" : "Password", reg ? "new-password" : "current-password")}
      ${reg ? pwField("f-pass2", "Confirm password", "new-password") + `<div class="meter"><span id="meter-bar"></span></div><div id="meter-label" class="hint"></div><ul id="rules" class="rules"></ul>`
            : `<label class="remember"><input type="checkbox" id="f-remember"> Keep me signed in on this device</label>`}
      <button class="btn block" id="auth-btn" type="submit">${reg ? "Create account" : "Sign in"}</button>
    </form>
    <div id="login-error" class="error-msg"></div>
  </div></div>`;

  root.querySelectorAll("[data-mode]").forEach(b => b.addEventListener("click", () => renderLogin(b.dataset.mode)));
  root.querySelectorAll("[data-eye]").forEach(b => b.addEventListener("click", () => {
    const i = $(b.dataset.eye), show = i.type === "password";
    i.type = show ? "text" : "password"; b.textContent = show ? "Hide" : "Show";
  }));

  if (reg) {
    const paint = () => {
      const r = Auth.rules($("f-pass").value, $("f-name").value, $("f-email").value);
      const ok = r.filter(x => x[1]).length;
      $("rules").innerHTML = r.map(x => `<li class="${x[1] ? "ok" : ""}">${x[1] ? "✓" : "○"} ${x[0]}</li>`).join("");
      $("meter-bar").style.width = Math.round(ok / r.length * 100) + "%";
      $("meter-bar").style.background = ok <= 2 ? "var(--red)" : ok < r.length ? "var(--amber)" : "var(--green)";
      $("meter-label").textContent = $("f-pass").value ? (ok <= 2 ? "Weak" : ok < r.length ? "Almost there" : "Strong password") : "";
    };
    ["f-pass", "f-name", "f-email"].forEach(id => $(id).addEventListener("input", paint));
    paint();
  }

  $("auth-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("login-error"), btn = $("auth-btn");
    err.textContent = ""; btn.disabled = true;
    try {
      const email = $("f-email").value.trim().toLowerCase(), pw = $("f-pass").value;
      if (reg) {
        if (pw !== $("f-pass2").value) throw new Error("Dono passwords match nahi kar rahe.");
        CURRENT = await Auth.register($("f-name").value, email, pw);
        Auth.start(email, false);
      } else {
        const old = Store.loadStudent(email);
        if (!Auth.has(email) && old) { renderLogin("register", { email, name: old.name, notice: "Ye profile purane version ka hai (bina password). Password set karke apna progress claim karo." }); return; }
        if (!Auth.has(email)) throw new Error("Account nahi mila — pehle 'Create account' se register karo.");
        CURRENT = await Auth.login(email, pw);
        Auth.start(email, $("f-remember").checked);
      }
      navigate(CURRENT.activeGoalId ? "/dashboard" : "/onboarding");
      render();
    } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
  });
}

function logout() {
  Auth.end(); CURRENT = null; QS = null;
  navigate("/login"); render();
}

// ---------------------------------------------------------------- onboarding

let onboardingGoal = null;

function renderOnboarding() {
  onboardingGoal = onboardingGoal || CURRENT.activeGoalId || null;

  root.innerHTML = h`
  <div class="center-screen">
    <div class="auth-card" style="max-width:640px;">
      <div class="brand">${HELIX_SVG}<div><div class="brand-name">LearnDNA</div><div class="brand-tag">step 1 of 2 — choose a goal</div></div></div>
      <h1 style="font-size:20px;margin-bottom:6px;">Hi ${esc(CURRENT.name.split(" ")[0])}, what are you working toward?</h1>
      <p style="color:var(--text-dim);font-size:13.5px;margin-bottom:18px;">LearnDNA maps your goal backward through prerequisites to build your roadmap.</p>
      <div id="goal-list">
        ${[...GOALS.values()].map(g => {
          const style = subjectStyle(g.id);
          return `
          <button class="goal-option ${onboardingGoal === g.id ? "selected" : ""}" data-goal="${g.id}" style="--accent:${style.color};">
            <div class="g-title"><span class="g-icon">${style.icon}</span>${esc(g.title)}</div>
            <div class="g-desc">${esc(g.description)}</div>
            <div class="g-meta">${g.requiredTopicIds.length} topics in this path</div>
          </button>`;
        }).join("")}
      </div>
      <button class="btn block" id="goal-next" ${onboardingGoal ? "" : "disabled"}>Next — quick self-assessment</button>
    </div>
  </div>`;

  root.querySelectorAll("[data-goal]").forEach(btn => {
    btn.addEventListener("click", () => { onboardingGoal = btn.dataset.goal; renderOnboarding(); });
  });
  document.getElementById("goal-next").addEventListener("click", () => {
    if (!onboardingGoal) return;
    renderAssessment(onboardingGoal);
  });
}

function renderAssessment(goalId) {
  const graph = SUBJECT_GRAPHS.get(goalId);
  const roadmap = graph.buildRoadmapForGoal(GOALS.get(goalId).requiredTopicIds);
  const picks = {}; // topicId -> score, only set once the user actually clicks an option

  root.innerHTML = h`
  <div class="center-screen">
    <div class="auth-card" style="max-width:640px;">
      <div class="brand">${HELIX_SVG}<div><div class="brand-name">LearnDNA</div><div class="brand-tag">step 2 of 2 — self-assessment</div></div></div>
      <h1 style="font-size:20px;margin-bottom:4px;">How well do you know these already?</h1>
      <p style="color:var(--text-dim);font-size:13.5px;margin-bottom:4px;">Be honest — quizzes later will refine this. This seeds your Knowledge DNA.</p>
      <p class="hint" id="assess-count" style="margin-bottom:14px;"></p>
      <div id="assess-list">
        ${roadmap.map(t => `
          <div class="assess-item" data-item="${t.id}">
            <div><div class="a-title">${esc(t.title)}</div><div class="a-meta">${t.domain} · ${t.difficulty.toLowerCase()}</div></div>
            <div class="assess-opts" data-topic="${t.id}">
              <button data-score="0">Don't know</button>
              <button data-score="40">Somewhat</button>
              <button data-score="85">Confident</button>
            </div>
          </div>`).join("")}
      </div>
      <button class="btn block" id="assess-done" style="margin-top:18px;" disabled>Answer all topics to continue</button>
    </div>
  </div>`;

  const total = roadmap.length;
  const doneBtn = document.getElementById("assess-done");
  const countEl = document.getElementById("assess-count");
  const refreshCount = () => {
    const answered = Object.keys(picks).length;
    countEl.textContent = `${answered} / ${total} answered`;
    if (answered === total) { doneBtn.disabled = false; doneBtn.textContent = "Build my Knowledge DNA"; }
    else { doneBtn.disabled = true; doneBtn.textContent = `Answer all topics to continue (${total - answered} left)`; }
  };
  refreshCount();

  root.querySelectorAll(".assess-opts").forEach(group => {
    const topicId = group.dataset.topic;
    group.querySelectorAll("button").forEach(btn => {
      btn.addEventListener("click", () => {
        picks[topicId] = Number(btn.dataset.score);
        group.querySelectorAll("button").forEach(b => b.classList.remove("picked"));
        btn.classList.add("picked");
        group.closest(".assess-item").classList.add("answered");
        refreshCount();
      });
    });
  });

  document.getElementById("assess-done").addEventListener("click", () => {
    if (Object.keys(picks).length < total) {
      const firstUnanswered = roadmap.find(t => picks[t.id] === undefined);
      if (firstUnanswered) {
        const el = root.querySelector(`[data-item="${firstUnanswered.id}"]`);
        el.classList.add("shake");
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        setTimeout(() => el.classList.remove("shake"), 500);
      }
      return;
    }
    roadmap.forEach(t => {
      CURRENT.dna.setMastery(t.id, picks[t.id]);
      CURRENT.progress.recordSession(t.id, picks[t.id]);
    });
    CURRENT.activeGoalId = goalId;
    persist();
    onboardingGoal = null;
    toast("Knowledge DNA created");
    navigate("/dashboard");
  });
}

// ---------------------------------------------------------------- multi-course

// A subject is "touched" once any of its topics has a progress record — dna.masteryMap
// is keyed by topic id and topic ids are unique across every subject, so mastery on one
// subject never overlaps or gets wiped by starting another.
function subjectStatus(subjId) {
  const topics = SUBJECT_GRAPHS.get(subjId).getAllTopics();
  const started = topics.some(t => !!CURRENT.progress.progressByTopic[t.id]);
  const completed = topics.filter(t => CURRENT.dna.getMastery(t.id) >= PASS_THRESHOLD).length;
  const avg = Math.round(topics.reduce((sum, t) => sum + CURRENT.dna.getMastery(t.id), 0) / topics.length);
  return { started, completed, total: topics.length, avg, done: completed === topics.length };
}

function renderSubjects() {
  const cards = [...GOALS.values()].map(g => {
    const style = subjectStyle(g.id);
    const st = subjectStatus(g.id);
    const isCurrent = g.id === CURRENT.activeGoalId;
    const label = st.done ? "Completed" : st.started ? "In progress" : "Not started";
    return h`
      <div class="card course-card" style="--accent:${style.color};">
        <div class="course-head"><span class="g-icon">${style.icon}</span><h3>${esc(g.title)}</h3>${isCurrent ? `<span class="badge building">viewing</span>` : ""}</div>
        <p class="hint" style="margin:2px 0 10px;">${esc(g.description)}</p>
        <div class="mastery-bar"><span style="width:${st.avg}%;background:${st.done ? "var(--teal)" : "var(--accent)"}"></span></div>
        <div class="course-meta"><span>${st.completed}/${st.total} mastered</span><span class="${st.done ? "" : st.started ? "" : "hint"}">${label}</span></div>
        <button class="btn ${isCurrent ? "ghost" : ""} small" data-subj="${g.id}" data-started="${st.started}" style="margin-top:10px;">${isCurrent ? "Go to dashboard" : st.started ? "Continue course" : "Start course"}</button>
      </div>`;
  }).join("");

  const content = h`
    <div class="page-head">
      <div class="eyebrow">my courses</div>
      <h1>Start a new course anytime</h1>
      <p class="lede">Progress is tracked per topic, so switching or adding a course never touches what you've already built in another one.</p>
    </div>
    <div class="grid cols-3">${cards}</div>
  `;
  shell("subjects", content);

  root.querySelectorAll("[data-subj]").forEach(btn => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.subj;
      if (id === CURRENT.activeGoalId) { navigate("/dashboard"); return; }
      if (btn.dataset.started === "true") {
        CURRENT.activeGoalId = id;
        persist();
        toast("Switched to " + GOALS.get(id).title);
        navigate("/dashboard");
      } else {
        renderAssessment(id); // fresh subject: quick self-assessment seeds its Knowledge DNA
      }
    });
  });
}

// ---------------------------------------------------------------- shell

const NAV_ITEMS = [
  ["dashboard", "Dashboard"],
  ["graph", "Knowledge Graph"],
  ["roadmap", "Roadmap"],
  ["revision", "Revision"],
  ["analytics", "Analytics"],
  ["subjects", "My Courses"],
];

function shell(route, contentHtml) {
  const style = subjectStyle(CURRENT.activeGoalId);
  root.innerHTML = h`
  <div class="shell" style="--accent:${style.color};">
    <aside class="sidebar">
      <div class="brand">${HELIX_SVG}<div><div class="brand-name">LearnDNA</div><div class="brand-tag">smart learning engine</div></div></div>
      <nav class="nav">
        ${NAV_ITEMS.map(([r, label]) => `<a href="#/${r}" class="${route === r ? "active" : ""}"><span class="dot"></span>${label}</a>`).join("")}
      </nav>
      <div class="sidebar-footer">
        <div class="who">${esc(CURRENT.name)}</div>
        <a class="subject-pill" href="#/subjects" style="border-color:${style.color};color:${style.color};">${style.icon} ${esc(GOALS.get(CURRENT.activeGoalId)?.title ?? "")} · switch</a>
        <button id="logout-btn">Sign out</button>
      </div>
    </aside>
    <main class="main">${contentHtml}</main>
  </div>`;
  document.getElementById("logout-btn").addEventListener("click", logout);
}

// ---------------------------------------------------------------- dashboard

function renderDashboard() {
  const graph = currentGraph();
  const engine = currentEngine();
  const goal = GOALS.get(CURRENT.activeGoalId);
  const dnaScore = CURRENT.dna.getOverallDnaScore();
  const completed = CURRENT.progress.countCompleted();
  const recs = engine.recommend(CURRENT, goal.id, 3);
  const weak = engine.weakTopics(CURRENT, 50).slice(0, 4);
  const revisionDue = getRevisionQueue(CURRENT, graph);

  const content = h`
    <div class="page-head">
      <div class="eyebrow">dashboard</div>
      <h1>Your Knowledge DNA</h1>
      <p class="lede">A live snapshot of what you know, what's next, and what needs revision — for ${esc(goal.title)}.</p>
    </div>

    <div class="grid cols-3" style="margin-bottom:16px;">
      <div class="card">
        <h3>Overall DNA score</h3>
        <div class="stat-row"><span class="stat">${dnaScore.toFixed(0)}%</span></div>
        <div class="mastery-bar" style="margin-top:10px;"><span style="width:${dnaScore}%"></span></div>
      </div>
      <div class="card">
        <h3>Topics mastered</h3>
        <div class="stat">${completed}<span style="font-size:16px;color:var(--text-faint);"> / ${goal.requiredTopicIds.length}</span></div>
        <div class="stat-label">required for this goal</div>
      </div>
      <div class="card">
        <h3>Due for revision</h3>
        <div class="stat" style="color:${revisionDue.length ? "var(--amber)" : "var(--text)"}">${revisionDue.length}</div>
        <div class="stat-label">${revisionDue.length ? "topics slipping" : "you're all caught up"}</div>
      </div>
    </div>

    <div class="grid cols-2">
      <div class="card">
        <h3>Recommended next</h3>
        ${recs.length ? recs.map(r => `
          <div style="padding:10px 0;border-bottom:1px solid var(--border);">
            <a href="#/topic/${r.topic.id}" style="color:var(--text);text-decoration:none;font-size:14px;">${esc(r.topic.title)}</a>
            <div style="color:var(--text-faint);font-size:12px;margin-top:3px;">${esc(r.reason)}</div>
          </div>`).join("") : `<div class="empty" style="padding:20px 0;">Nothing ready right now — check the roadmap for what unlocks next.</div>`}
      </div>
      <div class="card">
        <h3>Weak areas</h3>
        ${weak.length ? weak.map(t => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid var(--border);">
            <a href="#/topic/${t.id}" style="color:var(--text);text-decoration:none;font-size:14px;">${esc(t.title)}</a>
            <span class="mono" style="color:var(--coral);font-size:13px;">${CURRENT.dna.getMastery(t.id)}%</span>
          </div>`).join("") : `<div class="empty" style="padding:20px 0;">No weak spots detected yet.</div>`}
      </div>
    </div>

    <div class="divider"></div>
    <div class="section-title">quick actions</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <a class="btn" href="#/roadmap">View full roadmap</a>
      <a class="btn ghost" href="#/graph">Explore Knowledge Graph</a>
      <a class="btn ghost" href="#/revision">Open revision planner</a>
      <a class="btn ghost" href="#/subjects">Start / switch another course</a>
    </div>
  `;
  shell("dashboard", content);
}

// ---------------------------------------------------------------- roadmap

function renderRoadmap() {
  const graph = currentGraph();
  const goal = GOALS.get(CURRENT.activeGoalId);
  const roadmap = graph.buildRoadmapForGoal(goal.requiredTopicIds);
  const masteryLookup = (id) => CURRENT.dna.getMastery(id);

  let nextFound = false;
  const rows = roadmap.map((t, i) => {
    const mastery = CURRENT.dna.getMastery(t.id);
    const ready = graph.isReadyToLearn(t.id, masteryLookup);
    const completedFlag = mastery >= PASS_THRESHOLD;
    let tag = "";
    if (!nextFound && !completedFlag && ready) { tag = `<span class="badge building">start here</span>`; nextFound = true; }
    return h`
      <div class="topic-row" data-go="${t.id}" style="cursor:pointer;flex-wrap:wrap;">
        <span class="t-index mono">${String(i + 1).padStart(2, "0")}</span>
        <div class="t-main">
          <div class="t-title">${esc(t.title)} <span class="mono" style="color:var(--text-faint);font-size:11px;">${t.id}</span></div>
          <div class="mastery-bar t-bar"><span style="width:${mastery}%;background:${completedFlag ? "var(--teal)" : ready ? "var(--amber)" : "var(--coral)"}"></span></div>
        </div>
        <div class="t-side">
          ${tag}
          ${completedFlag ? masteryBadge(mastery) : ready ? "" : `<span class="badge locked">locked</span>`}
          <span class="mono" style="color:var(--text-dim);font-size:13px;">${mastery}%</span>
        </div>
        <div class="chips">${chips(t)}</div>
      </div>`;
  }).join("");

  const content = h`
    <div class="page-head">
      <div class="eyebrow">roadmap</div>
      <h1>${esc(goal.title)}</h1>
      <p class="lede">Goal-backward planning: every prerequisite this goal transitively needs, ordered by a topological sort so you never hit a locked topic.</p>
    </div>
    ${rows}
  `;
  shell("roadmap", content);
  root.querySelectorAll("[data-go]").forEach(r => r.addEventListener("click", e => { if (e.target.closest("a")) return; navigate("/topic/" + r.dataset.go); }));
}

// ---------------------------------------------------------------- graph explorer

function renderGraph() {
  const graph = currentGraph();
  const layers = graph.computeLayers();
  const byLayer = new Map();
  for (const t of graph.getAllTopics()) {
    const l = layers.get(t.id);
    if (!byLayer.has(l)) byLayer.set(l, []);
    byLayer.get(l).push(t);
  }
  const colW = 168, rowH = 92, padX = 60, padY = 40;
  const maxRows = Math.max(...[...byLayer.values()].map(a => a.length));
  const width = padX * 2 + (Math.max(...layers.values()) + 1) * colW;
  const height = padY * 2 + maxRows * rowH;

  const pos = {};
  for (const [layer, topics] of byLayer) {
    const colX = padX + layer * colW + colW / 2;
    const startY = padY + (height - padY * 2 - topics.length * rowH) / 2;
    topics.forEach((t, i) => { pos[t.id] = { x: colX, y: startY + i * rowH + rowH / 2 }; });
  }

  const masteryLookup = (id) => CURRENT.dna.getMastery(id);
  const nodeColor = (t) => {
    const m = CURRENT.dna.getMastery(t.id);
    if (m >= PASS_THRESHOLD) return "var(--teal)";
    if (graph.isReadyToLearn(t.id, masteryLookup)) return "var(--amber)";
    return "var(--coral)";
  };

  let edgesSvg = "";
  for (const t of graph.getAllTopics()) {
    for (const preId of graph.getPrerequisiteIds(t.id)) {
      const a = pos[preId], b = pos[t.id];
      const midX = (a.x + b.x) / 2;
      edgesSvg += `<path class="graph-edge" d="M${a.x + 46},${a.y} C${midX},${a.y} ${midX},${b.y} ${b.x - 46},${b.y}"/>`;
    }
  }

  let nodesSvg = "";
  for (const t of graph.getAllTopics()) {
    const p = pos[t.id];
    const color = nodeColor(t);
    nodesSvg += h`
      <g class="graph-node" data-topic="${t.id}" transform="translate(${p.x},${p.y})">
        <circle r="26" fill="rgba(255,255,255,0.03)" stroke="${color}"/>
        <text class="g-id" text-anchor="middle" y="-32">${t.id}</text>
        <text text-anchor="middle" y="5">${wrapTitle(t.title)}</text>
      </g>`;
  }

  const content = h`
    <div class="page-head">
      <div class="eyebrow">knowledge graph explorer</div>
      <h1>Topics &amp; prerequisites</h1>
      <p class="lede">Nodes are topics, edges point from a prerequisite to what it unlocks. Click a node for details.</p>
    </div>
    <div class="graph-wrap">
      <svg viewBox="0 0 ${width} ${height}" width="100%" style="min-width:${Math.max(width, 640)}px;">
        ${edgesSvg}
        ${nodesSvg}
      </svg>
    </div>
    <div class="legend">
      <span><span class="sw" style="background:var(--teal);"></span>mastered (≥ ${PASS_THRESHOLD}%)</span>
      <span><span class="sw" style="background:var(--amber);"></span>ready to start</span>
      <span><span class="sw" style="background:var(--coral);"></span>locked — prerequisites missing</span>
    </div>
  `;
  shell("graph", content);

  root.querySelectorAll(".graph-node").forEach(node => {
    node.addEventListener("click", () => navigate("/topic/" + node.dataset.topic));
  });
}

function wrapTitle(title) {
  const words = title.split(" ");
  if (words.length === 1) return esc(title);
  const mid = Math.ceil(words.length / 2);
  const line1 = words.slice(0, mid).join(" ");
  const line2 = words.slice(mid).join(" ");
  return `<tspan x="0" dy="-6">${esc(line1)}</tspan><tspan x="0" dy="13">${esc(line2)}</tspan>`;
}

// ---------------------------------------------------------------- topic detail

function renderTopicDetail(topicId) {
  QS = null;
  const graph = currentGraph();
  const t = graph.getTopic(topicId);
  const masteryLookup = (id) => CURRENT.dna.getMastery(id);
  const mastery = CURRENT.dna.getMastery(t.id);
  const ready = graph.isReadyToLearn(t.id, masteryLookup);
  const explanation = graph.explain(t.id, masteryLookup);
  const progress = CURRENT.progress.getOrCreate(t.id);
  const dependents = [...graph.getDependentIds(t.id)].map(id => graph.getTopic(id));

  const content = h`
    <div class="page-head">
      <div class="eyebrow">topic · ${t.domain} · ${t.difficulty.toLowerCase()} · ~${t.estimatedMinutes} min</div>
      <div class="detail-header">
        <div>
          <h1>${esc(t.title)}</h1>
          <p class="lede">${masteryBadge(mastery)} <span class="mono" style="color:var(--text-dim);margin-left:8px;">${mastery}% mastery</span></p>
        </div>
        <a class="btn" href="#/quiz/${t.id}">Take quiz</a>
      </div>
    </div>

    <div class="explain-box ${ready ? "ready" : "blocked"}">${esc(explanation)}</div>

    <div class="section-title">learning resources</div>
    ${t.resources.map(r => {
      const done = progress.completedResources?.includes(r.id);
      return `
      <div class="resource-row ${done ? "done" : ""}">
        <div style="display:flex;align-items:center;gap:12px;">
          <span class="r-type">${r.type}</span>
          <span class="r-title">${esc(r.title)}</span>
        </div>
        <button class="btn small ${done ? "ghost" : ""}" data-resource="${r.id}" ${!ready ? "disabled" : ""}>${done ? "Completed" : "Mark complete"}</button>
      </div>`;
    }).join("")}

    <div class="section-title" style="margin-top:22px;">course &amp; extra practice</div>
    <div class="chips">${chips(t, true)}</div>
    <div class="section-title" style="margin-top:22px;">top youtube videos</div>
    <div id="yt-box"></div>

    ${dependents.length ? `
      <div class="section-title" style="margin-top:22px;">unlocks next</div>
      ${dependents.map(d => `<a class="topic-row" href="#/topic/${d.id}" style="padding:12px 16px;"><div class="t-main"><div class="t-title" style="margin:0;">${esc(d.title)}</div></div></a>`).join("")}
    ` : ""}

    <div style="margin-top:26px;"><a class="btn ghost" href="#/roadmap">← back to roadmap</a></div>
  `;
  shell("topic", content);
  loadVideos(t, document.getElementById("yt-box"));

  root.querySelectorAll("[data-resource]").forEach(btn => {
    btn.addEventListener("click", () => {
      if (!ready) return;
      const rid = btn.dataset.resource;
      progress.completedResources = progress.completedResources || [];
      if (!progress.completedResources.includes(rid)) progress.completedResources.push(rid);
      const bumped = Math.min(100, mastery + 15);
      CURRENT.dna.setMastery(t.id, bumped);
      CURRENT.progress.recordSession(t.id, bumped);
      persist();
      toast("Progress saved — mastery up to " + bumped + "%");
      renderTopicDetail(topicId);
    });
  });
}

// ---------------------------------------------------------------- quiz

const QUIZ_ROUND = 5;
let QS = null; // { topicId, round, seen }
function shuffle(a) { a = [...a]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

function renderQuiz(topicId) {
  const graph = currentGraph();
  const t = graph.getTopic(topicId);
  const look = (id) => CURRENT.dna.getMastery(id);
  if (!graph.isReadyToLearn(topicId, look)) {
    shell("quiz", `<div class="page-head"><h1>${esc(t.title)}</h1></div><div class="explain-box blocked">${esc(graph.explain(topicId, look))}</div><a class="btn ghost" href="#/topic/${t.id}">← back</a>`);
    return;
  }
  if (!QS || QS.topicId !== topicId) QS = { topicId, round: 0, seen: {} };

  // pool = this topic's questions + revision questions from its prerequisites
  const pool = [
    ...(SEED_QUIZZES[topicId] || []).map(q => ({ ...q, from: t.title })),
    ...graph.dfsPrerequisiteChain(topicId).flatMap(p => (SEED_QUIZZES[p.id] || []).map(q => ({ ...q, from: p.title, rev: true }))),
  ];
  // least-seen questions first, so every new round shows fresh ones before repeating
  const picked = shuffle(pool).sort((a, b) => ((QS.seen[a.q] || 0) - (QS.seen[b.q] || 0)) || (!!a.rev - !!b.rev)).slice(0, QUIZ_ROUND);
  picked.forEach(q => QS.seen[q.q] = (QS.seen[q.q] || 0) + 1);
  const questions = picked.map(q => {
    const order = shuffle(q.options.map((_, i) => i));
    return { q: q.q, rev: q.rev, from: q.from, options: order.map(i => q.options[i]), answer: order.indexOf(q.answer) };
  });
  QS.round++;
  const round = QS.round;
  const answers = new Array(questions.length).fill(null);
  let result = null;

  function paint() {
    const answered = answers.filter(a => a !== null).length;
    const content = `
      <div class="page-head">
        <div class="eyebrow">quiz · round ${round}</div>
        <h1>${esc(t.title)}</h1>
        <p class="lede">Mastery ${CURRENT.dna.getMastery(t.id)}% — ${PASS_THRESHOLD}% pe topic mastered hota hai. Jab tak mastered nahi, naye rounds aate rahenge.</p>
      </div>
      <div class="card">
        <div class="round-bar"><span>Round ${round}</span><span>${answered}/${questions.length} answered</span></div>
        <div class="mastery-bar" style="margin-bottom:14px;"><span style="width:${answered / questions.length * 100}%"></span></div>
        ${questions.map((q, qi) => `
          <div class="quiz-q">
            ${q.rev ? `<div class="rev-tag">REVISION · ${esc(q.from)}</div>` : ""}
            <div class="q-text">${qi + 1}. ${esc(q.q)}</div>
            ${q.options.map((opt, oi) => {
              let cls = "quiz-opt";
              if (result) { if (oi === q.answer) cls += " correct"; else if (answers[qi] === oi) cls += " wrong"; }
              else if (answers[qi] === oi) cls += " picked";
              return `<button class="${cls}" data-q="${qi}" data-o="${oi}" ${result ? "disabled" : ""}>${esc(opt)}</button>`;
            }).join("")}
          </div>`).join("")}
        ${result ? `
          <div class="divider"></div>
          <p style="font-size:15px;">Score: <strong>${result.correct}/${questions.length}</strong> (${result.score}%) — mastery ${result.old}% → <strong style="color:var(--teal)">${result.now}%</strong></p>
          ${result.now >= PASS_THRESHOLD
            ? `<div class="explain-box ready">🎉 Topic mastered! Ab iske aage ke topics unlock ho gaye.</div><a class="btn" href="#/topic/${t.id}">Back to topic</a> <a class="btn ghost" href="#/roadmap">Roadmap</a>`
            : `<div class="explain-box blocked">Abhi mastered nahi (${result.now}% / ${PASS_THRESHOLD}%). Next round me nayi questions aayenge — chalte raho.</div><button class="btn" id="quiz-next">Start round ${round + 1} →</button> <a class="btn ghost" href="#/topic/${t.id}">Revise topic</a>`}
        ` : `<button class="btn" id="quiz-submit" ${answers.includes(null) ? "disabled" : ""}>Submit round ${round}</button>`}
      </div>`;
    shell("quiz", content);
    root.querySelectorAll(".quiz-opt").forEach(btn => btn.addEventListener("click", () => {
      if (result) return;
      answers[Number(btn.dataset.q)] = Number(btn.dataset.o);
      paint();
    }));
    const sub = document.getElementById("quiz-submit");
    if (sub) sub.addEventListener("click", () => {
      const correct = answers.filter((a, i) => a === questions[i].answer).length;
      const score = Math.round(correct / questions.length * 100);
      const old = CURRENT.dna.getMastery(t.id);
      const now = Math.round(0.4 * old + 0.6 * score);
      CURRENT.dna.setMastery(t.id, now);
      CURRENT.progress.recordSession(t.id, now);
      persist();
      result = { correct, score, old, now };
      paint();
    });
    const nxt = document.getElementById("quiz-next");
    if (nxt) nxt.addEventListener("click", () => renderQuiz(topicId));
  }
  paint();
}

// ---------------------------------------------------------------- revision

function renderRevision() {
  const graph = currentGraph();
  const due = getRevisionQueue(CURRENT, graph);
  const content = h`
    <div class="page-head">
      <div class="eyebrow">revision planner</div>
      <h1>Keep it fresh</h1>
      <p class="lede">Topics you've completed but haven't revisited in 3+ days, ranked by how urgently they need review.</p>
    </div>
    ${due.length ? due.map(d => `
      <div class="rev-row">
        <div>
          <div style="font-size:14.5px;">${esc(d.topic.title)}</div>
          <div style="color:var(--text-faint);font-size:12.5px;margin-top:3px;">last studied ${d.daysSince} day${d.daysSince === 1 ? "" : "s"} ago · mastery ${d.mastery}%</div>
        </div>
        <a class="btn small" href="#/quiz/${d.topic.id}">Quick review quiz</a>
      </div>`).join("") : `
      <div class="empty">
        <div class="display">Nothing due</div>
        <p>Come back after a few days of study — LearnDNA will flag topics before you forget them.</p>
      </div>`}
  `;
  shell("revision", content);
}

// ---------------------------------------------------------------- analytics

function renderAnalytics() {
  const graph = currentGraph();
  const goal = GOALS.get(CURRENT.activeGoalId);
  const topics = graph.getAllTopics();
  const byDomain = {};
  topics.forEach(t => {
    byDomain[t.domain] = byDomain[t.domain] || [];
    byDomain[t.domain].push(t);
  });

  const content = h`
    <div class="page-head">
      <div class="eyebrow">analytics</div>
      <h1>Progress by domain</h1>
      <p class="lede">Average mastery across every topic in each domain of the Knowledge Graph.</p>
    </div>
    <div class="grid cols-3" style="margin-bottom:24px;">
      ${Object.entries(byDomain).map(([domain, ts]) => {
        const avg = Math.round(ts.reduce((sum, t) => sum + CURRENT.dna.getMastery(t.id), 0) / ts.length);
        return `<div class="card"><h3>${esc(domain)}</h3><div class="stat">${avg}%</div><div class="mastery-bar" style="margin-top:10px;"><span style="width:${avg}%"></span></div></div>`;
      }).join("")}
    </div>

    <div class="section-title">every topic</div>
    <div class="card">
      ${topics.map(t => {
        const m = CURRENT.dna.getMastery(t.id);
        return `<div style="display:flex;align-items:center;gap:14px;padding:9px 0;border-bottom:1px solid var(--border);">
          <span style="width:150px;font-size:13.5px;flex-shrink:0;">${esc(t.title)}</span>
          <div class="mastery-bar" style="flex:1;"><span style="width:${m}%"></span></div>
          <span class="mono" style="width:40px;text-align:right;font-size:12.5px;color:var(--text-dim);">${m}%</span>
        </div>`;
      }).join("")}
    </div>
  `;
  shell("analytics", content);
}
