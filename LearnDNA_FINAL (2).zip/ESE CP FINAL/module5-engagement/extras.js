/* ===================================================================
   MODULE 5 -- Extras: dark/light theme, achievement badges, focus timer.
   =================================================================== */

const Theme = {
  KEY: "learndna:theme",
  get() { return localStorage.getItem(this.KEY) || "dark"; },
  apply() { document.documentElement.dataset.theme = this.get(); },
  toggle() { localStorage.setItem(this.KEY, this.get() === "dark" ? "light" : "dark"); this.apply(); },
};
Theme.apply();
document.addEventListener("click", e => { if (e.target.closest("#theme-btn")) { Theme.toggle(); e.target.closest("#theme-btn").textContent = Theme.get() === "dark" ? "☀ Light mode" : "🌙 Dark mode"; } });

// ---------------------------------------------------------------- badges
const BADGES = [
  ["🌱", "First Steps", "Complete a quiz round", (s, e) => e.xp > 0],
  ["🔥", "On Fire", "3-day streak", (s, e) => e.streak.best >= 3],
  ["⚡", "Unstoppable", "7-day streak", (s, e) => e.streak.best >= 7],
  ["💯", "Centurion", "Earn 100 XP", (s, e) => e.xp >= 100],
  ["🎓", "Scholar", "Earn 500 XP", (s, e) => e.xp >= 500],
  ["🧬", "Mastermind", "Master 1 topic", s => s.progress.countCompleted() >= 1],
  ["🏛", "Polymath", "Master 3 topics", s => s.progress.countCompleted() >= 3],
  ["✅", "Goal Getter", "Finish a custom goal", (s, e) => e.customGoals.some(g => g.done)],
  ["⏱", "Deep Focus", "60 focus minutes", (s, e) => (e.focusMin || 0) >= 60],
  ["👥", "Team Player", "Join a study group", s => Groups.mine(s.email).length > 0],
];
const Badges = {
  count() { const e = Engage.get(); return BADGES.filter(b => b[3](CURRENT, e)).length; },
  html() {
    const e = Engage.get();
    return `<div class="badges">${BADGES.map(([ic, n, d, f]) => `<div class="bdg ${f(CURRENT, e) ? "" : "lock"}"><div class="e">${ic}</div><div class="n">${n}</div><div class="d">${d}</div></div>`).join("")}</div>`;
  },
};

// ---------------------------------------------------------------- focus timer (survives page changes)
const FOCUS = { total: 25 * 60, left: 25 * 60, running: false, iv: null };
const CIRC = 2 * Math.PI * 108;

function focusPaint() {
  const t = document.getElementById("ftime"); if (!t) return;
  const m = String(Math.floor(FOCUS.left / 60)).padStart(2, "0"), s = String(FOCUS.left % 60).padStart(2, "0");
  t.textContent = `${m}:${s}`;
  document.getElementById("fring").setAttribute("stroke-dashoffset", String(CIRC * (1 - FOCUS.left / FOCUS.total)));
  document.getElementById("fstart").textContent = FOCUS.running ? "Pause" : (FOCUS.left < FOCUS.total ? "Resume" : "Start");
}
function focusDone() {
  clearInterval(FOCUS.iv); FOCUS.running = false;
  const min = Math.round(FOCUS.total / 60), e = Engage.get(), a = e.activity[Engage.today()] || (e.activity[Engage.today()] = { q: 0, c: 0, xp: 0 });
  a.min = (a.min || 0) + min; a.xp += min; e.xp += min; e.focusMin = (e.focusMin || 0) + min; persist();
  FOCUS.left = FOCUS.total;
  try { const ac = new (window.AudioContext || window.webkitAudioContext)(), o = ac.createOscillator(); o.connect(ac.destination); o.frequency.value = 880; o.start(); o.stop(ac.currentTime + .4); } catch { /* no audio */ }
  toast(`🎉 ${min} min focus complete! +${min} XP`); focusPaint();
}
function focusToggle() {
  if (FOCUS.running) { clearInterval(FOCUS.iv); FOCUS.running = false; }
  else { FOCUS.running = true; FOCUS.iv = setInterval(() => { FOCUS.left--; if (FOCUS.left <= 0) focusDone(); else focusPaint(); }, 1000); }
  focusPaint();
}

function renderFocus() {
  const e = Engage.get(), todayMin = e.activity[Engage.today()]?.min || 0;
  shell("focus", `
    <div class="page-head"><div class="eyebrow">focus timer</div><h1>Deep work session</h1>
      <p class="lede">Timer start karo aur padhai pe lag jao. Har poora focused minute = +1 XP. Page change karoge to bhi timer chalta rahega.</p></div>
    <div class="card"><div class="timer-wrap">
      <div class="ring"><svg width="240" height="240" viewBox="0 0 240 240"><circle cx="120" cy="120" r="108" fill="none" stroke="var(--track)" stroke-width="10"/>
        <circle id="fring" cx="120" cy="120" r="108" fill="none" stroke="var(--accent)" stroke-width="10" stroke-linecap="round" stroke-dasharray="${CIRC}" stroke-dashoffset="0"/></svg><div class="t" id="ftime">25:00</div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;">
        ${[15, 25, 50].map(m => `<button class="btn ghost small" data-preset="${m}" ${FOCUS.running ? "disabled" : ""}>${m} min</button>`).join("")}
      </div>
      <div style="display:flex;gap:10px;"><button class="btn" id="fstart">Start</button><button class="btn ghost" id="freset">Reset</button></div>
      <div class="hint">Aaj: ${todayMin} min focused · total ${e.focusMin || 0} min</div>
    </div></div>`);
  focusPaint();
  document.getElementById("fstart").onclick = focusToggle;
  document.getElementById("freset").onclick = () => { clearInterval(FOCUS.iv); FOCUS.running = false; FOCUS.left = FOCUS.total; focusPaint(); renderFocus(); };
  root.querySelectorAll("[data-preset]").forEach(b => b.onclick = () => { FOCUS.total = FOCUS.left = +b.dataset.preset * 60; renderFocus(); });
}
