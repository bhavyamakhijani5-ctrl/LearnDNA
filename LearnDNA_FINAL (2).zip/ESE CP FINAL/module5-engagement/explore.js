/* ===================================================================
   MODULE 5 -- Explore: "I want to learn ___" search across every subject,
   animated knowledge-network background, and saved topics ("profile").
   UI inspired by learn-anything.xyz.
   =================================================================== */

const Net = {
  words() { return SEED_SUBJECTS.flatMap(s => [s.title.split(" (")[0], ...s.topics.map(t => t.title)]); },
  mount(parent) {
    if (!parent) return;
    parent.querySelectorAll(".net-canvas").forEach(c => c.remove());
    const c = document.createElement("canvas"); c.className = "net-canvas"; parent.prepend(c);
    const ctx = c.getContext("2d"); if (!ctx) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1); let W = 0, H = 0;
    const size = () => { W = parent.clientWidth || 800; H = parent.clientHeight || 500; c.width = W * dpr; c.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); };
    size(); window.addEventListener("resize", () => { if (c.isConnected) size(); });
    const cols = ["#e5604f", "#d9885a", "#e9b15a", "#c9505f"], ws = this.words(), n = Math.min(54, Math.round(W * H / 15000) + 18);
    const nodes = Array.from({ length: n }, (_, i) => ({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .28, vy: (Math.random() - .5) * .28, w: ws[i % ws.length], hub: i < 7, col: cols[i % cols.length] }));
    const tick = () => {
      if (!c.isConnected) return;
      ctx.clearRect(0, 0, W, H);
      for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
        const d = Math.hypot(nodes[i].x - nodes[j].x, nodes[i].y - nodes[j].y);
        if (d < 190 || (nodes[i].hub && d < 330)) { ctx.strokeStyle = `rgba(160,160,170,${(1 - d / 330) * .28})`; ctx.lineWidth = .7; ctx.beginPath(); ctx.moveTo(nodes[i].x, nodes[i].y); ctx.lineTo(nodes[j].x, nodes[j].y); ctx.stroke(); }
      }
      for (const p of nodes) {
        p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1;
        ctx.font = `${p.hub ? 600 : 400} ${p.hub ? 17 : 12.5}px Inter, sans-serif`; ctx.fillStyle = p.col; ctx.globalAlpha = p.hub ? .95 : .7;
        ctx.fillText(p.w, p.x, p.y);
      }
      ctx.globalAlpha = 1; requestAnimationFrame(tick);
    };
    tick();
  },
};

const Saved = {
  list() { const e = Engage.get(); return e.saved || (e.saved = []); },
  has(key) { return this.list().includes(key); },
  toggle(key) { const l = this.list(), i = l.indexOf(key); if (i >= 0) l.splice(i, 1); else l.push(key); persist(); return i < 0; },
};

function allTopics() { return SEED_SUBJECTS.flatMap(s => s.topics.map(t => ({ ...t, sid: s.id, stitle: s.title.split(" (")[0] }))); }

function openTopic(sid, tid) {
  if (sid !== CURRENT.activeGoalId) { CURRENT.activeGoalId = sid; persist(); toast("Switched course to " + GOALS.get(sid).title); }
  navigate("/topic/" + tid);
}

function renderExplore() {
  const all = allTopics();
  const row = t => `<div class="lrow" data-go="${t.sid}|${t.id}"><button class="sbtn ${Saved.has(t.sid + "|" + t.id) ? "on" : ""}" data-save="${t.sid}|${t.id}" title="Save to profile">★</button><span>${esc(t.title)}</span><span class="meta">${esc(t.stitle)} · ${t.difficulty.toLowerCase()} · ${t.minutes}m</span></div>`;
  const savedRows = Saved.list().map(k => { const [sid, tid] = k.split("|"); return all.find(t => t.sid === sid && t.id === tid); }).filter(Boolean);
  const recs = currentEngine().recommend(CURRENT, CURRENT.activeGoalId, 4).map(r => all.find(t => t.sid === CURRENT.activeGoalId && t.id === r.topic.id)).filter(Boolean);

  shell("explore", `
    <div class="hero"><h1>I want to learn</h1>
      <input class="hero-search" id="q" autocomplete="off" aria-label="Search topics" placeholder="${esc(all[Math.floor(Math.random() * all.length)].title)}">
      <div class="res-list" id="res" style="display:none;"></div></div>
    ${recs.length ? `<div class="section-title">recommended for you</div><div class="card" style="padding:4px 0;">${recs.map(row).join("")}</div>` : ""}
    <div class="section-title" style="margin-top:22px;">saved topics (${savedRows.length})</div>
    <div class="card" style="padding:4px 0;">${savedRows.length ? savedRows.map(row).join("") : `<div class="empty" style="padding:18px;">★ dabake topics save karo — wo yaha dikhenge.</div>`}</div>`);

  Net.mount(root.querySelector(".hero"));
  const q = document.getElementById("q"), res = document.getElementById("res"); q.focus();
  const ph = setInterval(() => { if (!document.body.contains(q)) return clearInterval(ph); if (!q.value) q.placeholder = all[Math.floor(Math.random() * all.length)].title; }, 2200);
  q.addEventListener("input", () => {
    const s = q.value.trim().toLowerCase(); if (!s) { res.style.display = "none"; return; }
    const hits = all.filter(t => (t.title + " " + t.domain + " " + t.stitle).toLowerCase().includes(s)).slice(0, 8);
    res.style.display = "block";
    res.innerHTML = hits.map(row).join("") + `<div class="lrow" data-ask="${esc(q.value)}">🤖 Ask the assistant: "${esc(q.value)}"</div>`;
  });
  q.addEventListener("keydown", e => { if (e.key === "Enter") { const f = res.querySelector("[data-go]") || res.querySelector("[data-ask]"); if (f) f.click(); } });
  root.querySelector(".main").addEventListener("click", e => {
    const ask = e.target.closest("[data-ask]"); if (ask) { Assistant.open(ask.dataset.ask); return; }
    if (e.target.closest("[data-save]")) return;
    const go = e.target.closest("[data-go]"); if (go) { const [sid, tid] = go.dataset.go.split("|"); openTopic(sid, tid); }
  });
}

// save-star works everywhere (explore rows + topic page header)
document.addEventListener("click", e => {
  const b = e.target.closest("[data-save]"); if (!b || !CURRENT) return;
  e.stopPropagation();
  const on = Saved.toggle(b.dataset.save); b.classList.toggle("on", on); toast(on ? "Saved to profile" : "Removed from profile");
}, true);
