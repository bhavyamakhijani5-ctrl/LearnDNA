# LearnDNA — Web Version

Ye tumhare Java LearnDNA project ka **website version** hai — same logic (Knowledge Graph, topological sort, rule-based recommendation engine, mastery scoring, revision planner), bas ab ye seedha browser mein chalega. Koi Java compile / classpath / IDE setup nahi chahiye.

## Kaise chalayein (2 tareeke)

**Sabse simple:** `index.html` file par seedha double-click karo — browser mein khul jayega, poora app kaam karega.

**Better (recommended for demo/viva):** kisi bhi text editor / VS Code se folder kholo aur ek local server chalao, phir browser mein `http://localhost:8000` kholo:
```
python3 -m http.server 8000
```
(Local server thoda zyada reliable hai kyunki fonts vagera load hote hain, lekin double-click wala tareeka bhi 100% chalega.)

Koi npm install, koi backend, koi database setup nahi chahiye — sab kuch pure HTML/CSS/JS hai, data browser ke `localStorage` mein save hota hai (naya student banao ya wapas login karo, same email se progress wapas mil jayega).

## Flow

1. **Sign in** — naam + email daalo (naya profile automatic ban jata hai)
2. **Goal chuno** — Java Backend Developer ya Database Fundamentals
3. **Self-assessment** — har topic pe "Don't know / Somewhat / Confident" — isse tumhari **Knowledge DNA** banti hai
4. **Dashboard** — overall DNA score, weak areas, recommended next topics
5. **Knowledge Graph Explorer** — sabhi topics aur unke prerequisites ka visual graph (teal = mastered, amber = ready, coral = locked)
6. **Roadmap** — goal-backward planning se generate hua ordered learning path (topological sort)
7. **Topic page** — resources complete karo, mastery badhti hai
8. **Quiz** — 3 MCQs per topic, submit karne pe mastery score update hoti hai
9. **Revision planner** — jo topics 3+ din se revise nahi kiye, wo yaha flag hote hain
10. **Analytics** — domain-wise (Java / Database / Web) average mastery

## File structure

```
index.html          -> entry point, isko hi open karna hai
css/styles.css       -> saara styling
js/data.js           -> seed data: 9 topics, 2 goals, quiz questions (Java DataSeeder se liya)
js/models.js         -> Topic, Goal, Student, KnowledgeDNA, ProgressTracker classes
js/graph.js          -> KnowledgeGraph: BFS, DFS, topological sort, prerequisite checking
js/engine.js         -> RuleBasedRecommendationEngine + revision queue logic
js/store.js          -> localStorage persistence layer
js/app.js            -> routing + saari screens ka rendering
```

## Java se mapping (viva ke liye)

Ye web version tumhare original Java classes ke naam aur logic ko hi follow karta hai, taaki explain karna easy rahe:

| Java class | Web equivalent |
|---|---|
| `learndna.model.Topic`, `Goal`, `Student`, `KnowledgeDNA` | `js/models.js` — same fields, same methods |
| `learndna.graph.KnowledgeGraph` (BFS/DFS/Kahn's topo sort/cycle check) | `js/graph.js` — line-by-line same algorithm, JS Map/Set instead of Java HashMap/HashSet |
| `learndna.engine.RuleBasedRecommendationEngine` (goal relevance + readiness + weakness + time fit scoring) | `js/engine.js` — same scoring formula |
| `learndna.util.DataSeeder` | `js/data.js` — same T1–T9 topics, same G1 goal, same prerequisite edges |
| Java Swing GUI (`MainFrame`, `DashboardPanel`, `RoadmapPanel`, `TopicExplorerPanel`, `QuizPanel`) | `js/app.js` screens — Dashboard, Roadmap, Graph Explorer, Topic page, Quiz |
| JDBC Data Access Layer | `js/store.js` (`localStorage` — no server/DB needed for the demo) |

Isse tum bata sakte ho ki OOP design same hi hai, sirf presentation + persistence layer ko web ke liye swap kiya hai (jaisa documentation ke "Future Scope" mein already likha hai: *"Mobile/web version using Spring Boot + React/Android"*).

## Update v2
- **Auth:** Sign in + Create account tabs, password strength rules + live meter, show/hide, confirm password, lockout after 5 wrong tries. Password localStorage me **PBKDF2-SHA256 hash + salt** ke roop me save hota hai (inspect karne pe plain password nahi dikhega). `js/auth.js`
- **Quiz:** rounds of 5 (topic + prerequisite revision questions, shuffled), mastered (70%) hone tak naye rounds.
- **Roadmap/Topic:** har topic pe YouTube, full course, GeeksforGeeks, practice, NPTEL links. Optional YouTube Data API key daalo to topic page pe top-4 video cards aate hain.
- Note: ye frontend-only demo hai; production me hashing server par honi chahiye.

## Update v3 — split into 4 modules (team submission)

Code is now divided into 4 independent module folders, so each team member can own and present one:

| Module | Folder | Contains | Owner focus |
|---|---|---|---|
| **1 — Data & Knowledge Graph** | `module1-data-knowledge-graph/` | `data.js` (seed subjects/topics/quiz bank), `models.js` (Student, KnowledgeDNA, Progress), `graph.js` (KnowledgeGraph — prerequisites, ready-to-learn) | Domain data & structures |
| **2 — Adaptive Engine & Quiz System** | `module2-adaptive-engine-quiz/` | `engine.js` (rule-based recommendation engine), `quiz.js` (round-based quiz runner, repeats until mastered) | Adaptive logic |
| **3 — Dashboard, Roadmap & Analytics UI** | `module3-dashboard-roadmap-analytics/` | `ui.js` — course picker + self-assessment, dashboard, roadmap, graph explorer, topic detail (+ external links/videos), revision planner, analytics | Learner-facing screens |
| **4 — Login & Integration** | `module4-login-integration/` | `auth.js` (register/login/hashing/session), `store.js` (localStorage persistence), `core.js` (global wiring, router, login screen, sidebar shell — boots the whole app) | Auth + gluing everything together |

**Load order matters** (see `index.html`): Module 1 → Module 2 → Module 3 → Module 4. Module 4 loads last because `core.js` wires Module 1's data into live Knowledge Graph objects and fires the app on `DOMContentLoaded`.

All 4 modules still run as one app — this is a source-level split for team ownership/viva, not separate deployments.

## Update v4 — Module 5: Engagement (end-sem features)

New folder `module5-engagement/` (loaded before Module 4 in `index.html`; the existing modules got only small hooks):

| Feature | Where | How it works |
|---|---|---|
| **Streaks & daily goals** | `engage.js` → `#/goals`, dashboard cards | Daily question target (3–20, default 5). Meeting it = streak day; missing a day resets it. 5-week activity heatmap. |
| **Custom goals** | `engage.js` → `#/goals` | Goals like "answer 20 questions" or "master 2 topics" auto-track from quizzes; "manual" goals have a Mark-done button. Optional deadline. |
| **XP & levels** | `engage.js` | +10 per correct answer, +20 per round, +50 per mastered topic, +25 daily bonus, +30 per goal. 100 XP = 1 level. |
| **Quiz explanations** | `tutor.js` (+ hook in `quiz.js`) | After submitting a round, every question shows right/wrong, the correct answer and an "Explain why" button. |
| **AI tutor** | `tutor.js` → `#/tutor` | Online mode if you paste an Anthropic API key (stays in your browser's localStorage). Offline mode (no key) answers from the Knowledge Graph: topic facts, prerequisites, resources, practice questions. |
| **Leaderboard & study groups** | `community.js` → `#/community` | All-time / weekly XP ranking. Create a group → share the 6-letter code → friends join. "Add 5 demo classmates" fills the board for a demo. |

Limits to mention in viva: leaderboard/groups are **per browser** (localStorage, no backend), so they work across accounts created on the same device. Quiz explanations are generated (AI) or templated (offline), not hand-written per question.
Integration points: `Student.engage` (models.js), `Engage.onQuiz()` call in `quiz.js`, 3 routes + nav items in `core.js`, `Engage.dashCard()` in `ui.js`.

## Update v5 — final polish (UI + assistant)

- **Dark-first UI** (`css/theme.css`, learn-anything.xyz style) with a light-mode toggle in the sidebar. Login screen has an animated knowledge-network background (`Net` in `explore.js`).
- **Explore page** (`#/explore`): "I want to learn ___" search across all 7 courses, ★ save topics to your profile, recommended + saved lists. Clicking a topic from another course switches the course automatically.
- **Topic page**: resources are a checklist with circle toggles (mark complete), ★ save, "Ask AI" shortcut.
- **LearnDNA Assistant** (`assistant.js`): floating chatbot on every screen (💬). Works offline via an intent router (English + Hinglish) that reads/changes real student data: *stats, weak topics, next topic, revision due, N-day study plan, set daily goal, add goal, switch course, start quiz, open any page, rank, motivation, theme*. Voice input (🎤, Chrome). Unknown questions go to Claude if an API key is saved, else the offline tutor. Shares chat history with the AI Tutor page.
- **Badges** (10 achievements) on the Goals page, **Focus timer** (`#/focus`, +1 XP per focused minute; keeps running while you navigate).
- Files: `explore.js`, `assistant.js`, `extras.js` (Theme, Badges, Focus).

## Update v6 — Gemini + revision notes

- **Gemini API** (`tutor.js`): AI Tutor page → *AI settings* → paste a Google Gemini key (free from aistudio.google.com/apikey), choose provider (Gemini / Claude), click *Test connection*. Default model `gemini-3.6-flash` (editable; auto-falls back to `gemini-flash-latest` / `gemini-2.5-flash`). Key stays in localStorage only.
- **Answers follow the question**: typing a quiz answer ("Palindrome", "B") is now graded; "what is array" returns a real definition + key points (built-in bank for all 51 topics in `notes.js`); with a Gemini key the model answers the exact question.
- **Revision notes** (`#/revision`): every topic has definition, key points, quick Q&A from the quiz bank, prerequisites, links, AI-generated notes (✨), and your own auto-saved notes. Search box + *Download all (.md)* for end-sem.
- Quiz explanations now include the topic definition.
